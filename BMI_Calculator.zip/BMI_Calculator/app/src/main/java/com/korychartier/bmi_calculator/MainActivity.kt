package com.korychartier.bmi_calculator

import android.content.ContentValues.TAG
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import androidx.constraintlayout.widget.ConstraintLayout
import com.korychartier.bmi_calculator.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view : ConstraintLayout = binding.root
        setContentView(view)
        binding.etWeight.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun afterTextChanged(p0: Editable?) {
                Log.i(TAG,"afterTextChanged $p0")
                computeBMI()
            }
        })
        binding.etFeet.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int){}

            override fun afterTextChanged(p0: Editable?) {
                Log.i(TAG,"afterTextChanged $p0")
                computeBMI()
            }
        })
        binding.etInches.addTextChangedListener(object: TextWatcher{
            override fun beforeTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun onTextChanged(p0: CharSequence?, p1: Int, p2: Int, p3: Int) {}

            override fun afterTextChanged(p0: Editable?) {
                Log.i(TAG,"afterTextChanged $p0")
                computeBMI()
            }
        } )

    }
    private fun computeBMI() {
        if (binding.etWeight.text.toString().isEmpty()){
            binding.tvBmi.text = ""
            return
        }
        if(binding.etFeet.text.toString().isEmpty()){
            binding.tvBmi.text = ""
            return
        }
        if(binding.etInches.text.toString().isEmpty()){
            binding.tvBmi.text = ""
            return
        }
        val baseWeight = binding.etWeight.text.toString().toDouble()
        val baseFeet = binding.etFeet.text.toString().toDouble()
        val baseInches = binding.etInches.text.toString().toDouble()
        val baseHeight = baseFeet * 12 + baseInches
        val baseBMI = (baseWeight/baseHeight/baseHeight) * 703
        val bmiDescrip : String
        when (baseBMI) {
            in 0.00..18.50 -> bmiDescrip ="Underweight"
            in 18.51..24.99 -> bmiDescrip ="Ideal"
            in 25.00..29.99 -> bmiDescrip ="Overweight"
            else -> bmiDescrip = "Obese"
        }
        binding.tvBmi.text = "%.2f".format(baseBMI)

        binding.tvDetail.text = bmiDescrip
    }
}